package com.java.Dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.pojo.Event;
import com.java.pojo.User;

public class EventDao extends Dao {
	private PreparedStatement insertStatement;
	private PreparedStatement selectStatement;
	private PreparedStatement deleteStatement;
	private PreparedStatement retrieveStatement;
	private PreparedStatement updateStatement;
	private PreparedStatement select;
	
	public EventDao() throws Exception
	{
		super();
		this.insertStatement = this.connection.prepareStatement("insert into event values(?,?,?,?)");
		this.selectStatement = this.connection.prepareStatement("select * from event where techtalkId=?");
		this.deleteStatement = this.connection.prepareStatement("delete from event where techtalkId=?");
		this.retrieveStatement = this.connection.prepareStatement("select * from event");
		this.updateStatement = this.connection.prepareStatement("update event set date=?,description=?,presenter=? where techtalkId=?");
		this.select = this.connection.prepareStatement("select email from event where techtalkId =?");
	}
	
	//admin work to add event//
	public int addEvent( Event event )throws Exception
	{
		this.insertStatement.setString(4,null);
		this.insertStatement.setString(1, event.getDate());		
		this.insertStatement.setString(2, event.getDescription());	
		this.insertStatement.setString(3, event.getPresenter());
		return this.insertStatement.executeUpdate();
	}
	
	//admin work to delete event//
	public int deleteEvent(String techtalkId)throws Exception
	{
		this.deleteStatement.setString(1,techtalkId);
		return this.deleteStatement.executeUpdate();
	}
	public Event selectById(int id)throws Exception
	{
		/*this.selectStatement.setInt(1,(int) object);
		return this.selectStatement.executeUpdate();*/
		String sql = "select * from event where techtalkId='"+id+"'";
		PreparedStatement p1 = connection.prepareStatement(sql);
		ResultSet rs = p1.executeQuery();
		Event e1=null;
		while(rs.next())
		{
			String techtalkId =  rs.getString("techtalkId");
			String date =  rs.getString("date");
			String description =  rs.getString("description");
			String presenter =  rs.getString("presenter");
			e1 = new Event(techtalkId, date, description, presenter);
			
			
		}
		return e1;
	}
	public int updateEvent(String id ,Event e2)throws Exception
	{
		int id1 = Integer.parseInt(id);
		
		String sql = "update event set date='"+e2.getDate()+"',description='"+e2.getDescription()+"',presenter='"+e2.getPresenter()+"'where techtalkId ="+id+"";
		PreparedStatement p1 = connection.prepareStatement(sql);
		System.out.println("999999999999999999999999999999999999999999999"+sql);
		return p1.executeUpdate();
		
	}
	/*public int updateRecord( BookPojo book )throws Exception
	{
		this.updateStatement.setString(1, book.getBookName());
		this.updateStatement.setString(2, book.getAuthorName());
		this.updateStatement.setFloat(3, book.getPrice());
		this.updateStatement.setInt(4, book.getBookId());
		return this.updateStatement.executeUpdate();
		
		update event set date='2017/01/01','datattttttttttttttt','sandeep'where techtalkId =10
		
	}*/
	
	//showing list to employee and admin//
	public List<Event> showEvent()throws Exception
	{
		String sql = "select * from event";
		PreparedStatement p1 = connection.prepareStatement(sql);
		List<Event> eventlist = new  ArrayList<Event>();
		ResultSet rs = p1.executeQuery();
		
		
		
		while( rs.next())
		{
			Event event  = new Event(rs.getString("date"),rs.getString("description"),rs.getString("presenter"));
			eventlist.add(event);
		}
		return eventlist;

	}
	
	public List<Event> updateshowEvent()throws Exception
	{
		ResultSet rs = this.retrieveStatement.executeQuery();
		List<Event> eventlist = new  ArrayList<Event>();
		while( rs.next())
		{
			Event event  = new Event(rs.getString("techtalkId"),rs.getString("date"),rs.getString("description"),rs.getString("presenter"));
			eventlist.add(event);
		}
		return eventlist;
	}
	@Override
	public void close() throws IOException 
	{
		try
		{
			this.insertStatement.close();
			this.selectStatement.close();
			this.deleteStatement.close();
			this.retrieveStatement.close();
			super.close();
		}
		catch (SQLException e)
		{
			throw new IOException(e);
		}
	}
}
