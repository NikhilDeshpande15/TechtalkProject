package com.java.Dao;
import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dao implements Closeable
{
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/test";
	private static final String USER = "root";
	private static final String PASSWORD = "root";
	
	public Connection connection;
	public Dao()throws Exception
	{
		this.connection = this.getConnection();
	}
	
	private Connection getConnection()throws Exception
	{
		Class.forName(DRIVER);
		if( this.connection == null )
			this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
		return this.connection;
	}
	@Override
	public void close() throws IOException
	{
		try
		{
			this.connection.close();
		}
		catch (SQLException e)
		{
			throw new IOException(e);
		}
	}
}
