package com.java.Dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.pojo.User;

public class DaoConnection extends Dao{
	private PreparedStatement insertStatement;
	private PreparedStatement selectStatement;
	private PreparedStatement deleteStatement;
	//private PreparedStatement updateStatement;
	public DaoConnection() throws Exception
	{
		 super();
		this.insertStatement = this.connection.prepareStatement("insert into usertable values(?,?,?,?)");
		this.selectStatement = this.connection.prepareStatement("select * from usertable where email=? and password=?");
		this.deleteStatement = this.connection.prepareStatement("delete from usertable where email=?");
	}
	
	/*public DaoConnection(String driver, String url, String user, String password)throws Exception
	{
		
		this.insertStatement = this.connection.prepareStatement("insert into usertable values(?,?,?,?)");
		this.selectStatement = this.connection.prepareStatement("select * from usertable where userName=? and password=?");
		this.deleteStatement = this.connection.prepareStatement("delete from usertable where email=?");
	}
	
*/	//register new user//
	public int registerNewUser( User user )throws Exception
	{
		this.insertStatement.setString(1, user.getUserName());
		this.insertStatement.setString(2, user.getPassword());
		this.insertStatement.setString(3, user.getEmail());	
		this.insertStatement.setString(4, user.getRole());
		return this.insertStatement.executeUpdate();
	}
	
	//validate user//
	public User validateUser( String email, String password )throws Exception
	{
		System.out.println("inside validateUser......");
		this.selectStatement.setString(1,email);
		this.selectStatement.setString(2,password);
		
		User user = null;
		try(ResultSet rs =  this.selectStatement.executeQuery();)
		{
			if( rs.next())
				user = new User(rs.getString("userName"), rs.getString("password"),rs.getString("email"),rs.getString("role"));
			System.out.println(user);
		}
		System.out.println(user);
		return user;
	}
	
	//
	
	@Override
	public void close() throws IOException 
	{
		try
		{
			this.insertStatement.close();
			this.selectStatement.close();
			this.deleteStatement.close();
			super.close();
		}
		catch (SQLException e)
		{
			throw new IOException(e);
		}
	}
}
