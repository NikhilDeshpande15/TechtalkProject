package com.java.Controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.Dao.DaoConnection;
import com.java.pojo.User;

@WebServlet("/registrationServlet")
public class RegistrationServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		this.handleRequest(request, response);
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		this.handleRequest(request, response);
	}
	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("inside registration servlet");
		response.setContentType("text/html");
		
				String email = request.getParameter("txtEmail");
				String userName = request.getParameter("txtUserName");
				String password = request.getParameter("txtPassword");
				String role = request.getParameter("role");
				User user = new User(email, userName, password, role);
				try {		
					DaoConnection dao = new DaoConnection();
					dao.registerNewUser(user);
					
					System.out.println("inserted in database"+user);
				} catch (Exception e) {
					
					e.printStackTrace();
				}				
					System.out.println("in registration controller");
					
					/*RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
					rd.forward(request, response);*/
				response.sendRedirect("login.jsp");
				
		}
	
	
}
