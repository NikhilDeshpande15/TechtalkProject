package com.java.Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.Dao.DaoConnection;
import com.java.Dao.EventDao;
import com.java.pojo.Event;
import com.java.pojo.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	//private  DaoConnection dao;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		this.handleRequest(request, response);
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		this.handleRequest(request, response);
	}
	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String email = request.getParameter("txtEmail");
		String password = request.getParameter("txtPassword");
		
		response.setContentType("text/html");
		HttpSession session = request.getSession(true);	
			//RequestDispatcher rd = request.getRequestDispatcher("employeePage.jsp");
			try
			{   
				DaoConnection dao =new DaoConnection();
				EventDao edao = new EventDao();
				User user = dao.validateUser(email, password);
				List<Event> e = edao.showEvent();//list of event is taken
				
				System.out.println("inside login servlet");
				
				if(user.getRole().equals("employee"))
				{	
					session.setAttribute("username", user.getUserName());
					session.setAttribute("emailId", user.getEmail());				
					
					request.setAttribute("eventList", e);//list is added in session
					
					RequestDispatcher rd=request.getRequestDispatcher("employeePage.jsp");
					rd.forward(request, response);
				}
				else if(user.getRole().equals("admin"))
				{
					session.setAttribute("username", user.getUserName());
					RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
					rd.forward(request, response);
				}
				else
				{
					PrintWriter out=response.getWriter();
					out.write("Login Failed...");
					RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
					rd.forward(request, response);
				}
				
			}
			catch (Exception e)
			{
				throw new IOException(e);
			}			
		
	}
	
}

