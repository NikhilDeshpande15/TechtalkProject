package com.java.Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.Dao.EventDao;
import com.java.pojo.Event;

@WebServlet("/adminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;	
	
	public AdminServlet() {
        super();   
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.handleRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.handleRequest(request, response);
	}

	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("inside admin servlet");
		response.setContentType("text/html");
		HttpSession session = request.getSession(true);
		try
		{
			EventDao dao =new EventDao();
			
			String date = request.getParameter("txtDate");			
			String desc = request.getParameter("txtDescription");
			String presenter = request.getParameter("txtPresenter");
			
			Event event = new Event(date,desc, presenter);
			System.out.println("in admin controller"+event);
			
			dao.addEvent(event);//adding techtalk to db
			System.out.println("event added ");
			response.sendRedirect("admin.jsp");//redirected to admin page
			/*
			String techtalk = request.getParameter("txtTechtalk");//delete
			dao.deleteEvent(techtalk);*/
			
			/*List<Event>	list = dao.showEvent();
			session.setAttribute("list", list);*/
			
		}
		catch (Exception e)
		{
			throw new IOException(e);
		}
	
	}
	
		
}

