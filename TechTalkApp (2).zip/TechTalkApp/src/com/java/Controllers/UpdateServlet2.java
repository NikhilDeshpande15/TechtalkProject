package com.java.Controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.Dao.EventDao;
import com.java.pojo.Event;

/**
 * Servlet implementation class UpdateServlet2
 */
@WebServlet("/UpdateServlet2")
public class UpdateServlet2 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		handleRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		handleRequest(request, response);
	}
	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{	
		String date = request.getParameter("date");
		String disc = request.getParameter("desc");
		String preseter = request.getParameter("presenter");
		String id = request.getParameter("id");
		Event e2 = new Event(date, disc, preseter);
		//Event e1 = (Event)request.getAttribute("event1");
		//System.out.println("88888888888888888888888888"+e1);
		System.out.println("99999999999999999999999999"+e2);
		EventDao dao;
		try {
			dao = new EventDao();
			
			dao.updateEvent(id,e2);
			
			response.sendRedirect("admin.jsp");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
