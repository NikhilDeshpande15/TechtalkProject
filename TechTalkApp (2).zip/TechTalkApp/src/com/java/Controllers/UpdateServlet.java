package com.java.Controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.Dao.EventDao;
import com.java.pojo.Event;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.handleRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.handleRequest(request, response);
	}

	protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{		
		
		System.out.println("inside update servlet");
		response.setContentType("text/html");
		HttpSession session = request.getSession(true);
		String action = request.getParameter("action");
//		String techtalk = request.getParameter("updateId");
//		System.out.println(request.getParameter("updateId"));
//		int id =Integer.parseInt(techtalk);
		
		
		
		System.out.println("5555555555555555555555555555555555"+request.getParameter("techId"));
		/*RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		rd.forward(request, response);*/
		
		
			try {
				
				Event e = new Event();
				
				EventDao dao =new EventDao();
				
				//response.sendRedirect("update.jsp");

				
				
				Event e1 = dao.selectById(Integer.parseInt(request.getParameter("techId")+""));
				String date = e1.getDate();		
				String desc = e1.getDescription();
				String presenter = e1.getPresenter();
				   /*dao.updateEvent(e1);*/
				
				System.out.println("7777777777777777777777"+e1);
				request.setAttribute("event", e1);
								
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
				
				} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			
				
		
	}
}
