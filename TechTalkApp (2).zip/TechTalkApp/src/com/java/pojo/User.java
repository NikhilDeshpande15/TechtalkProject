package com.java.pojo;
//this is connected to database//
public class User {

	private String role;
	private String userName;
	private String password;
	private String email;
	public User()
	{
		this("","","","");
	}
	public User(String userName, String password, String email,String role)
	{
		this.email = email;
		this.userName = userName;
		this.password = password;		
		this.role = role;
	}
	public String getUserName()
	{
		return userName;
	}
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString()
	{
		return String.format("%-30s%-50s%-30s", this.userName,this.email,this.role);
	}	
	
	
}
