package com.java.pojo;

import java.sql.Date;

public class Event {
	private String techtalkId;
	private String date;	
	private String description;
	private String presenter;
	
	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Event(String date,  String description, String presenter) {
		super();
	
		this.date = date;		
		this.description = description;
		this.presenter = presenter;
	}
	public Event(String techtalkId,String date,  String description, String presenter) {
		super();
		this.techtalkId = techtalkId;
		this.date = date;		
		this.description = description;
		this.presenter = presenter;
	}

	public String getTechtalkId() {
		return techtalkId;
	}

	public void setTechtalkId(String techtalkId) {
		this.techtalkId = techtalkId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPresenter() {
		return presenter;
	}

	public void setPresenter(String presenter) {
		this.presenter = presenter;
	}

	@Override
	public String toString() {
		return "Event [techtalkId=" + techtalkId + ", date=" + date + ", description=" + description + ", presenter="
				+ presenter + "]";
	}

	
}
